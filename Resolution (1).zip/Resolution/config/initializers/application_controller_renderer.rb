# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '7121de565bb76b89f80308812f0bc20bee1bd2e1c6fa876d783175038ff89c012ef2a373a5a21d5f2c867a5919fe64b80a54e5e0ba2b0ee196bb723010103116'
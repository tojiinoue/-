require 'test_helper'

class DiaryTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

module DiariesHelper
end
